# PNU_3992_AR

# زینب ایزدی دخرآبادی 
-  [PNU_3992_AR](https://github.com/zeynabizadi/PNU_3992_AR/blob/main/README.md)
- [حساب گیت هاب](https://github.com/zeynabizadi)

- [رزومه](https://zeynabizadi.github.io/zeynab.izadi/)

- [sop](https://zeynabizadi.github.io/SOP/)

- [JavaScript certificate](https://github.com/zeynabizadi/PNU_3992_AR/blob/main/js.png)
- [patchwork](https://github.com/zeynabizadi/PNU_3992_AR/blob/main/jlord.png)
- [HTML](https://github.com/zeynabizadi/PNU_3992_AR/blob/main/Html.jpg )
- [CSS](https://github.com/zeynabizadi/PNU_3992_AR/blob/main/Css.jpg)

 
 ---
#  ارزیابی
 -  [ارزیابی رزومه و انگیزه نامه](https://github.com/zeynabizadi/PNU_3992_AR/blob/main/XX_CV_CheckList_AR_3992.pdf)
 -  [خلاصه ارزیابی بخش عمومی](https://github.com/zeynabizadi/PNU_3992_AR/blob/main/XX_GeneralSection_CheckList_AR_3992.pdf)


---


# دروس کارشناسی
کارآموزی 
-  [فرم های کارآموزی](https://github.com/zeynabizadi/PNU_3992_AR/blob/main/report.pdf)
-  [چک لیست گزارش کارآموزی](https://github.com/zeynabizadi/PNU_3992_AR/blob/main/checklist-ar3992.pdf)
-  [گزارش کارآموزی](https://github.com/zeynabizadi/PNU_3992_AR/blob/main/internshipreportAR3992.pdf)
